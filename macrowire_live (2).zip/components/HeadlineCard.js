
export default function HeadlineCard({ item }) {
  return (
    <article className="rounded-lg bg-gray-900 shadow p-6 border border-gray-800 space-y-4">
      <header className="flex justify-between text-sm">
        <h3 className="font-serif font-semibold text-lg">{item.headline}</h3>
        <span className="text-gray-400">{new Date(item.datetime).toLocaleTimeString([], {hour:'2-digit',minute:'2-digit'})}</span>
      </header>
      <p className="text-sm text-gray-300">{item.summary}</p>
      <a href={item.url} target="_blank" rel="noreferrer" className="text-[var(--mw-accent)] underline text-sm">Open source ↗</a>
    </article>
  )
}
