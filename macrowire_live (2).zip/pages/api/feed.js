
export default async function handler(req, res) {
  const FINNHUB_KEY = process.env.FINNHUB_KEY;
  const NEWSAPI_KEY = process.env.NEWSAPI_KEY;

  if (!FINNHUB_KEY || !NEWSAPI_KEY) {
    return res.status(500).json({ error: "API keys missing" });
  }

  const finnhubUrl = `https://finnhub.io/api/v1/news?category=general&token=${FINNHUB_KEY}`;
  const newsapiUrl = `https://newsapi.org/v2/top-headlines?language=en&apiKey=${NEWSAPI_KEY}`;

  try {
    const [finnRes, newsRes] = await Promise.all([
      fetch(finnhubUrl).then(r => r.json()),
      fetch(newsapiUrl).then(r => r.json())
    ]);

    const finnhubItems = (finnRes || []).slice(0, 10).map(i => ({
      source: i.source || "Finnhub",
      headline: i.headline,
      summary: i.summary || "",
      url: i.url,
      datetime: i.datetime || Date.now()
    }));

    const newsItems = (newsRes.articles || []).slice(0, 10).map(a => ({
      source: a.source.name || "NewsAPI",
      headline: a.title,
      summary: a.description || "",
      url: a.url,
      datetime: new Date(a.publishedAt).getTime()
    }));

    const merged = [...finnhubItems, ...newsItems]
      .sort((a, b) => b.datetime - a.datetime)
      .slice(0, 20);

    res.setHeader("Cache-Control", "s-maxage=60, stale-while-revalidate");
    res.status(200).json(merged);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
}
