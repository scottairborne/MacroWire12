
import Head from 'next/head'
import useSWR from 'swr'
import HeadlineCard from '../components/HeadlineCard'

const fetcher = url => fetch(url).then(r => r.json())

export default function Home() {
  const { data, error } = useSWR('/api/feed', fetcher, { refreshInterval: 60000 })

  return (
    <div className="bg-gray-950 text-gray-100 min-h-screen">
      <Head>
        <title>MacroWire – Live Macro Newsfeed</title>
        <link href="https://fonts.googleapis.com/css2?family=Merriweather:wght@400;700&family=Inter:wght@400;600&display=swap" rel="stylesheet" />
      </Head>
      <header className="px-6 py-4 bg-gray-900 shadow">
        <h1 className="font-serif text-2xl"><span className="font-serif">Macro</span><span className="font-bold text-[var(--mw-accent)]">Wire</span></h1>
      </header>
      <main className="p-6 space-y-6">
        {error && <p className="text-red-400">Error loading feed.</p>}
        {!data && <p className="text-gray-400">Loading…</p>}
        {data && data.map(item => <HeadlineCard key={item.url} item={item} />)}
      </main>
    </div>
  )
}
